<?php
require 'config/conex.php'; 

 
    $seleccionado = $_POST['seleccionado'];
    $cedula = $_POST['cedula'];
    $correo = $_POST['correo'];
      

        
            
            $sql = "INSERT INTO parcial (cedula, correo, seleccionado) VALUES ('$cedula', '$correo', '$seleccionado')";
            
if ($dbh ->query($sql)) {

            echo "voto exitoso: $seleccionado.";
}
 else {
                echo "Error al registrar el voto.";
            }
                
 
?>