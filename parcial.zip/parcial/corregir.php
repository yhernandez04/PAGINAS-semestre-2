<?php
require 'config/conex.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $documento = $_POST['documento'];
    $nuevo_correo = $_POST['nuevo_correo'];
    $nueva_persona = $_POST['nueva_persona'];

    try {
        $sql = "UPDATE parcial SET correo = :nuevo_correo, seleccionado = :nueva_persona WHERE cedula = :documento";
        $stmt = $dbh->prepare($sql);

        $stmt->bindParam(':nuevo_correo', $nuevo_correo);
        $stmt->bindParam(':nueva_persona', $nueva_persona);
        $stmt->bindParam(':documento', $documento);

        if ($stmt->execute()) {
            echo "Datos actualizados correctamente. Nuevo correo: $nuevo_correo, Nueva persona votada: $nueva_persona.";
        } else {
        
        }
    } catch (PDOException $e) {
        
    }
}
?>